Run the below command to instll the dependency :

npm install